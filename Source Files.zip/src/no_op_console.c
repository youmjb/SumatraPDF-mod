#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    printf("This is just a dummy program to satisfy premake. argc: %d, argv: %p\n", argc, argv);
    return 0;
}
