//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SumatraPDF.rc
//
#define IDI_SUMATRAPDF                  1

#define IDD_DIALOG_GOTO_PAGE            129
#define IDD_DIALOG_GET_PASSWORD         130
#define IDD_DIALOG_PDF_ASSOCIATE        131
#define IDC_CURSORDRAG                  132
#define IDD_DIALOG_CHANGE_LANGUAGE      134
#define IDD_DIALOG_SETTINGS             136
#define IDD_DIALOG_FIND                 137 
#define IDD_DIALOG_CUSTOM_ZOOM          138
#define IDD_PROPSHEET_PRINT_ADVANCED    139
#define IDD_DIALOG_FAV_ADD              140

#define IDC_GOTO_PAGE_EDIT              1000
#define IDC_GOTO_PAGE_GO                1001
#define IDC_BUTTON2                     1002
#define IDC_GOTOPAGE_CANCEL             1003
#define IDC_GOTO_PAGE_CANCEL            1004
#define IDC_GOTO_PAGE_LABEL_OF          1005
#define IDC_DIALOG_GET_PASSWORD_EDIT    1006
#define IDC_GET_PASSWORD_EDIT           1007
#define IDC_GET_PASSWORD_LABEL          1008
#define IDC_REMEMBER_PASSWORD           1009
#define IDC_TOOLBAR                     1010
#define IDC_REBAR                       1011
#define IDC_EDIT1                       1012
#define IDC_FAV_NAME_EDIT               1013
#define IDC_DONT_ASK_ME_AGAIN           1014
#define IDC_ADD_PAGE_STATIC             1015
#define IDC_CHANGE_LANG_LANG_LIST       1017
#define IDC_SECTION_VIEW                1021
#define IDC_DEFAULT_LAYOUT_LABEL        1022
#define IDC_DEFAULT_LAYOUT              1023
#define IDC_DEFAULT_ZOOM_LABEL          1024
#define IDC_DEFAULT_ZOOM                1025
#define IDC_DEFAULT_SHOW_TOC            1026
#define IDC_REMEMBER_STATE_PER_DOCUMENT 1027
#define IDC_SECTION_ADVANCED            1028
#define IDC_CHECK_FOR_UPDATES           1029
#define IDC_REMEMBER_OPENED_FILES       1031
#define IDC_FIND_EDIT                   1032
#define IDC_MATCH_CASE                  1033
#define IDC_FIND_NEXT_HINT              1034
#define IDC_SECTION_INVERSESEARCH       1040
#define IDC_CMDLINE_LABEL               1041
#define IDC_CMDLINE                     1042
#define IDC_USE_TABS                    1045
#define IDC_SECTION_PRINT_RANGE         1050
#define IDC_PRINT_RANGE_ALL             1051
#define IDC_PRINT_RANGE_EVEN            1052
#define IDC_PRINT_RANGE_ODD             1053
#define IDC_SECTION_PRINT_SCALE         1060
#define IDC_PRINT_SCALE_SHRINK          1061
#define IDC_PRINT_SCALE_FIT             1062
#define IDC_PRINT_SCALE_NONE            1063
#define IDC_SECTION_PRINT_COMPATIBILITY 1070
#define IDC_TOC_LABEL_WITH_CLOSE        1101
#define IDC_FAV_LABEL_WITH_CLOSE        1106
#define IDB_RELOADING_CUE               2010

#define IDC_STATIC                      -1

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1080
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
